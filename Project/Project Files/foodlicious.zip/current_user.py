#!/home/foodlicious/mypython/bin/python
import sys
user=sys.argv[1]
def currentuser():
    return int(user)