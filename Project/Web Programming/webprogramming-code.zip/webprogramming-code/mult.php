<html>
<body>
<TITLE>Multiplication results</TITLE>
<H3>Multiplication results</H3>

<?php 
	$m = $_GET["m"]; 
	$n = $_GET["n"];
	$result = $m * $n; 
	print("<P> The product of $m and $n is $result");
?>

</body>
</html>
